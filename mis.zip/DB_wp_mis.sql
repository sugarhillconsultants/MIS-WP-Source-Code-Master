-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2019 at 03:24 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wp_mis`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-08-05 12:35:22', '2019-08-05 12:35:22', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/wp/mis', 'yes'),
(2, 'home', 'http://localhost/wp/mis', 'yes'),
(3, 'blogname', 'MIS', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'nextgenanakgida@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:104:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:36:\"question/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"question/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"question/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"question/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"question/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"question/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:25:\"question/([^/]+)/embed/?$\";s:41:\"index.php?question=$matches[1]&embed=true\";s:29:\"question/([^/]+)/trackback/?$\";s:35:\"index.php?question=$matches[1]&tb=1\";s:37:\"question/([^/]+)/page/?([0-9]{1,})/?$\";s:48:\"index.php?question=$matches[1]&paged=$matches[2]\";s:44:\"question/([^/]+)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?question=$matches[1]&cpage=$matches[2]\";s:33:\"question/([^/]+)(?:/([0-9]+))?/?$\";s:47:\"index.php?question=$matches[1]&page=$matches[2]\";s:25:\"question/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:35:\"question/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:55:\"question/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"question/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"question/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:31:\"question/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=27&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";i:2;s:43:\"custom-post-type-ui/custom-post-type-ui.php\";i:3;s:37:\"post-types-order/post-types-order.php\";i:4;s:37:\"user-role-editor/user-role-editor.php\";i:5;s:56:\"wp-front-end-login-and-register/wp-mp-register-login.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:90:\"D:\\xampp\\htdocs\\wp\\mis/wp-content/plugins/custom-list-table-example/list-table-example.php\";i:1;s:0:\"\";}', 'no'),
(40, 'template', 'twentyfifteen', 'yes'),
(41, 'stylesheet', 'mis', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:43:\"wp-jquery-datatable/wp-jquery-datatable.php\";s:16:\"wp_jdt_uninstall\";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '27', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '38590', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:68:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:14:\"ure_edit_roles\";b:1;s:16:\"ure_create_roles\";b:1;s:16:\"ure_delete_roles\";b:1;s:23:\"ure_create_capabilities\";b:1;s:23:\"ure_delete_capabilities\";b:1;s:18:\"ure_manage_options\";b:1;s:15:\"ure_reset_roles\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:1:{s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'cron', 'a:5:{i:1567431322;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1567470922;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1567514135;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1567515416;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(112, 'theme_mods_twentyseventeen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1565008754;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(116, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:6:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.2.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.2.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.2\";s:7:\"version\";s:5:\"5.2.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.2.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.2.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.2\";s:7:\"version\";s:5:\"5.2.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.2.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.2.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.1\";s:7:\"version\";s:5:\"5.2.1\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:3;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-5.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-5.2.zip\";s:10:\"no_content\";s:68:\"https://downloads.wordpress.org/release/wordpress-5.2-no-content.zip\";s:11:\"new_bundled\";s:69:\"https://downloads.wordpress.org/release/wordpress-5.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:3:\"5.2\";s:7:\"version\";s:3:\"5.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:4;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.1.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.1.1\";s:7:\"version\";s:5:\"5.1.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:5;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.4-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.4\";s:7:\"version\";s:5:\"5.0.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}}s:12:\"last_checked\";i:1567428825;s:15:\"version_checked\";s:6:\"4.9.10\";s:12:\"translations\";a:0:{}}', 'no'),
(127, 'can_compress_scripts', '1', 'no'),
(140, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1567428829;s:7:\"checked\";a:2:{s:3:\"mis\";s:5:\"1.0.0\";s:13:\"twentyfifteen\";s:3:\"2.5\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(141, 'current_theme', 'MIS', 'yes'),
(142, 'theme_mods_twentyfifteen', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1565246848;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(143, 'theme_switched', '', 'yes'),
(148, 'recently_activated', 'a:2:{s:48:\"custom-list-table-example/list-table-example.php\";i:1567146659;s:43:\"wp-jquery-datatable/wp-jquery-datatable.php\";i:1566972619;}', 'yes'),
(149, 'acf_version', '5.3.7', 'yes'),
(158, 'cptui_new_install', 'false', 'yes'),
(161, 'cpto_options', 'a:7:{s:23:\"show_reorder_interfaces\";a:2:{s:4:\"post\";s:4:\"show\";s:10:\"attachment\";s:4:\"show\";}s:8:\"autosort\";i:1;s:9:\"adminsort\";i:1;s:18:\"use_query_ASC_DESC\";s:0:\"\";s:17:\"archive_drag_drop\";i:1;s:10:\"capability\";s:14:\"manage_options\";s:21:\"navigation_sort_apply\";i:1;}', 'yes'),
(162, 'CPT_configured', 'TRUE', 'yes'),
(165, 'user_role_editor', 'a:8:{s:11:\"ure_version\";s:6:\"4.51.2\";s:15:\"show_admin_role\";i:0;s:17:\"ure_caps_readable\";i:0;s:24:\"ure_show_deprecated_caps\";i:0;s:23:\"ure_confirm_role_update\";s:1:\"1\";s:14:\"edit_user_caps\";s:1:\"1\";s:18:\"caps_columns_quant\";i:1;s:19:\"other_default_roles\";a:0:{}}', 'yes'),
(166, 'wp_backup_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'no'),
(167, 'ure_tasks_queue', 'a:0:{}', 'yes'),
(170, 'cptui_post_types', 'a:1:{s:8:\"question\";a:29:{s:4:\"name\";s:8:\"question\";s:5:\"label\";s:9:\"Questions\";s:14:\"singular_label\";s:8:\"Question\";s:11:\"description\";s:0:\"\";s:6:\"public\";s:4:\"true\";s:18:\"publicly_queryable\";s:4:\"true\";s:7:\"show_ui\";s:4:\"true\";s:17:\"show_in_nav_menus\";s:4:\"true\";s:12:\"show_in_rest\";s:4:\"true\";s:9:\"rest_base\";s:0:\"\";s:21:\"rest_controller_class\";s:0:\"\";s:11:\"has_archive\";s:5:\"false\";s:18:\"has_archive_string\";s:0:\"\";s:19:\"exclude_from_search\";s:5:\"false\";s:15:\"capability_type\";s:4:\"post\";s:12:\"hierarchical\";s:5:\"false\";s:7:\"rewrite\";s:4:\"true\";s:12:\"rewrite_slug\";s:0:\"\";s:17:\"rewrite_withfront\";s:4:\"true\";s:9:\"query_var\";s:4:\"true\";s:14:\"query_var_slug\";s:0:\"\";s:13:\"menu_position\";s:0:\"\";s:12:\"show_in_menu\";s:4:\"true\";s:19:\"show_in_menu_string\";s:0:\"\";s:9:\"menu_icon\";s:0:\"\";s:8:\"supports\";a:2:{i:0;s:5:\"title\";i:1;s:6:\"editor\";}s:10:\"taxonomies\";a:0:{}s:6:\"labels\";a:24:{s:9:\"menu_name\";s:0:\"\";s:9:\"all_items\";s:0:\"\";s:7:\"add_new\";s:0:\"\";s:12:\"add_new_item\";s:0:\"\";s:9:\"edit_item\";s:0:\"\";s:8:\"new_item\";s:0:\"\";s:9:\"view_item\";s:0:\"\";s:10:\"view_items\";s:0:\"\";s:12:\"search_items\";s:0:\"\";s:9:\"not_found\";s:0:\"\";s:18:\"not_found_in_trash\";s:0:\"\";s:17:\"parent_item_colon\";s:0:\"\";s:14:\"featured_image\";s:0:\"\";s:18:\"set_featured_image\";s:0:\"\";s:21:\"remove_featured_image\";s:0:\"\";s:18:\"use_featured_image\";s:0:\"\";s:8:\"archives\";s:0:\"\";s:16:\"insert_into_item\";s:0:\"\";s:21:\"uploaded_to_this_item\";s:0:\"\";s:17:\"filter_items_list\";s:0:\"\";s:21:\"items_list_navigation\";s:0:\"\";s:10:\"items_list\";s:0:\"\";s:10:\"attributes\";s:0:\"\";s:14:\"name_admin_bar\";s:0:\"\";}s:15:\"custom_supports\";s:0:\"\";}}', 'yes'),
(178, 'WPLANG', '', 'yes'),
(179, 'new_admin_email', 'nextgenanakgida@gmail.com', 'yes'),
(184, 'category_children', 'a:0:{}', 'yes'),
(218, 'theme_mods_mis', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(251, 'wpmp_redirect_settings', 'a:2:{s:19:\"wpmp_login_redirect\";s:2:\"73\";s:20:\"wpmp_logout_redirect\";s:2:\"27\";}', 'yes'),
(252, 'wpmp_display_settings', 'a:10:{s:24:\"wpmp_email_error_message\";s:46:\"Could not able to send the email notification.\";s:30:\"wpmp_account_activated_message\";s:51:\"Your account has been activated. You can login now.\";s:33:\"wpmp_account_notactivated_message\";s:72:\"Your account has not been activated yet, please verify your email first.\";s:24:\"wpmp_login_error_message\";s:34:\"Username or password is incorrect.\";s:26:\"wpmp_login_success_message\";s:31:\"You are successfully logged in.\";s:41:\"wpmp_password_reset_invalid_email_message\";s:44:\"We cannot identify any user with this email.\";s:37:\"wpmp_password_reset_link_sent_message\";s:51:\"A link to reset your password has been sent to you.\";s:40:\"wpmp_password_reset_link_notsent_message\";s:29:\"Password reset link not sent.\";s:35:\"wpmp_password_reset_success_message\";s:44:\"Your password has been changed successfully.\";s:41:\"wpmp_invalid_password_reset_token_message\";s:33:\"This token appears to be invalid.\";}', 'yes'),
(253, 'wpmp_form_settings', 'a:10:{s:19:\"wpmp_signup_heading\";s:8:\"Register\";s:19:\"wpmp_signin_heading\";s:5:\"Login\";s:26:\"wpmp_resetpassword_heading\";s:14:\"Reset Password\";s:23:\"wpmp_signin_button_text\";s:5:\"Login\";s:23:\"wpmp_signup_button_text\";s:8:\"Register\";s:30:\"wpmp_returntologin_button_text\";s:15:\"Return to Login\";s:32:\"wpmp_forgot_password_button_text\";s:15:\"Forgot Password\";s:30:\"wpmp_resetpassword_button_text\";s:14:\"Reset Password\";s:19:\"wpmp_enable_captcha\";s:1:\"1\";s:27:\"wpmp_enable_forgot_password\";s:1:\"1\";}', 'yes'),
(254, 'wpmp_email_settings', 'a:8:{s:25:\"wpmp_notification_subject\";s:21:\"Welcome to %BLOGNAME%\";s:25:\"wpmp_notification_message\";s:390:\"Thank you for registering on %BLOGNAME%.\n<br><br>\n<strong>First Name :</strong> %FIRSTNAME%<br>\n<strong>Last Name : </strong>%LASTNAME%<br>\n<strong>Username :</strong> %USERNAME%<br>\n<strong>Email :</strong> %USEREMAIL%<br>\n<strong>Password :</strong> As choosen at the time of registration.\n<br><br>\nPlease visit %BLOGURL% to login.\n<br><br>\nThanks and regards,\n<br>\nThe team at %BLOGNAME%\";s:29:\"wpmp_admin_email_notification\";s:1:\"1\";s:28:\"wpmp_user_email_confirmation\";s:1:\"1\";s:43:\"wpmp_new_account_verification_email_subject\";s:38:\"%BLOGNAME% | Please confirm your email\";s:43:\"wpmp_new_account_verification_email_message\";s:186:\"Thank you for registering on %BLOGNAME%.\n<br><br>\nPlease confirm your email by clicking on below link :\n<br><br>\n%ACTIVATIONLINK%\n<br><br>\nThanks and regards,\n<br>\nThe team at %BLOGNAME%\";s:33:\"wpmp_password_reset_email_subject\";s:27:\"%BLOGNAME% | Password Reset\";s:33:\"wpmp_password_reset_email_message\";s:204:\"Hello %USERNAME%,\n<br><br>\nWe have received a request to change your password.\nClick on the link to change your password : \n<br><br>\n%RECOVERYLINK%\n<br><br>\nThanks and regards,\n<br>\nThe team at %BLOGNAME%\";}', 'yes'),
(292, 'ure_role_additional_options_values', 'a:1:{s:10:\"subscriber\";a:0:{}}', 'yes'),
(380, 'options_logo', '63', 'no'),
(381, '_options_logo', 'field_5d57731302d4c', 'no'),
(382, 'options_title', 'WP Phase 2 Intergration', 'no'),
(383, '_options_title', 'field_5d57732e4dbc2', 'no'),
(384, 'options_description', 'Automated On-boarding Tool used for capturing project details ans requirements.', 'no'),
(385, '_options_description', 'field_5d5773474dbc3', 'no'),
(404, '_site_transient_timeout_browser_01b80466de9751fc3c1cfc72f0950804', '1567502866', 'no'),
(405, '_site_transient_browser_01b80466de9751fc3c1cfc72f0950804', 'a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"68.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:24:\"https://www.firefox.com/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(430, '_site_transient_timeout_browser_471e4b86e3560c6feb474def098169b6', '1567577037', 'no'),
(431, '_site_transient_browser_471e4b86e3560c6feb474def098169b6', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"76.0.3809.132\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(539, '_transient_timeout_acf_pro_get_remote_info', '1567446649', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(540, '_transient_acf_pro_get_remote_info', 'a:16:{s:4:\"name\";s:26:\"Advanced Custom Fields PRO\";s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:8:\"homepage\";s:36:\"https://www.advancedcustomfields.com\";s:7:\"version\";s:5:\"5.8.3\";s:6:\"author\";s:13:\"Elliot Condon\";s:10:\"author_url\";s:36:\"https://www.advancedcustomfields.com\";s:12:\"contributors\";s:12:\"elliotcondon\";s:8:\"requires\";s:5:\"4.7.0\";s:6:\"tested\";s:3:\"5.2\";s:4:\"tags\";a:100:{i:0;s:5:\"5.8.2\";i:1;s:5:\"5.8.1\";i:2;s:13:\"5.8.0-beta4.1\";i:3;s:11:\"5.8.0-beta4\";i:4;s:11:\"5.8.0-beta3\";i:5;s:11:\"5.8.0-beta2\";i:6;s:11:\"5.8.0-beta1\";i:7;s:9:\"5.8.0-RC2\";i:8;s:9:\"5.8.0-RC1\";i:9;s:5:\"5.8.0\";i:10;s:5:\"5.7.9\";i:11;s:5:\"5.7.8\";i:12;s:5:\"5.7.7\";i:13;s:5:\"5.7.6\";i:14;s:5:\"5.7.5\";i:15;s:5:\"5.7.4\";i:16;s:5:\"5.7.3\";i:17;s:5:\"5.7.2\";i:18;s:6:\"5.7.13\";i:19;s:6:\"5.7.12\";i:20;s:6:\"5.7.10\";i:21;s:5:\"5.7.1\";i:22;s:5:\"5.7.0\";i:23;s:5:\"5.6.9\";i:24;s:5:\"5.6.8\";i:25;s:5:\"5.6.7\";i:26;s:5:\"5.6.6\";i:27;s:5:\"5.6.5\";i:28;s:5:\"5.6.4\";i:29;s:5:\"5.6.3\";i:30;s:5:\"5.6.2\";i:31;s:6:\"5.6.10\";i:32;s:5:\"5.6.1\";i:33;s:11:\"5.6.0-beta2\";i:34;s:11:\"5.6.0-beta1\";i:35;s:9:\"5.6.0-RC2\";i:36;s:9:\"5.6.0-RC1\";i:37;s:5:\"5.6.0\";i:38;s:5:\"5.5.9\";i:39;s:5:\"5.5.7\";i:40;s:5:\"5.5.5\";i:41;s:5:\"5.5.3\";i:42;s:5:\"5.5.2\";i:43;s:6:\"5.5.14\";i:44;s:6:\"5.5.13\";i:45;s:6:\"5.5.12\";i:46;s:6:\"5.5.11\";i:47;s:6:\"5.5.10\";i:48;s:5:\"5.5.1\";i:49;s:5:\"5.5.0\";i:50;s:5:\"5.4.8\";i:51;s:5:\"5.4.7\";i:52;s:5:\"5.4.6\";i:53;s:5:\"5.4.5\";i:54;s:5:\"5.4.4\";i:55;s:5:\"5.4.3\";i:56;s:5:\"5.4.2\";i:57;s:5:\"5.4.1\";i:58;s:5:\"5.4.0\";i:59;s:5:\"5.3.9\";i:60;s:5:\"5.3.8\";i:61;s:5:\"5.3.7\";i:62;s:5:\"5.3.6\";i:63;s:5:\"5.3.5\";i:64;s:5:\"5.3.4\";i:65;s:5:\"5.3.3\";i:66;s:5:\"5.3.2\";i:67;s:6:\"5.3.10\";i:68;s:5:\"5.3.1\";i:69;s:5:\"5.3.0\";i:70;s:5:\"5.2.9\";i:71;s:5:\"5.2.8\";i:72;s:5:\"5.2.7\";i:73;s:5:\"5.2.6\";i:74;s:5:\"5.2.5\";i:75;s:5:\"5.2.4\";i:76;s:5:\"5.2.3\";i:77;s:5:\"5.2.2\";i:78;s:5:\"5.2.1\";i:79;s:5:\"5.2.0\";i:80;s:5:\"5.1.9\";i:81;s:5:\"5.1.8\";i:82;s:5:\"5.1.7\";i:83;s:5:\"5.1.6\";i:84;s:5:\"5.1.5\";i:85;s:5:\"5.1.4\";i:86;s:5:\"5.1.3\";i:87;s:5:\"5.1.2\";i:88;s:5:\"5.1.1\";i:89;s:5:\"5.1.0\";i:90;s:5:\"5.0.9\";i:91;s:5:\"5.0.8\";i:92;s:5:\"5.0.7\";i:93;s:5:\"5.0.6\";i:94;s:5:\"5.0.5\";i:95;s:5:\"5.0.4\";i:96;s:5:\"5.0.3\";i:97;s:5:\"5.0.2\";i:98;s:5:\"5.0.1\";i:99;s:5:\"5.0.0\";}s:6:\"tagged\";s:61:\"acf, advanced, custom, field, fields, form, repeater, content\";s:11:\"description\";s:1353:\"<p>Use the Advanced Custom Fields plugin to take full control of your WordPress edit screens & custom field data.</p>\n<p><strong>Add fields on demand.</strong> Our field builder allows you to quickly and easily add fields to WP edit screens with only the click of a few buttons!</p>\n<p><strong>Add them anywhere.</strong> Fields can be added all over WP including posts, users, taxonomy terms, media, comments and even custom options pages!</p>\n<p><strong>Show them everywhere.</strong> Load and display your custom field values in any theme template file with our hassle free developer friendly functions!</p>\n<h4>Features</h4>\n<ul>\n<li> Simple & Intuitive</li>\n<li> Powerful Functions</li>\n<li> Over 30 Field Types</li>\n<li> Extensive Documentation</li>\n<li> Millions of Users</li>\n</ul>\n<h4>Links</h4>\n<ul>\n<li> <a href=\"https://www.advancedcustomfields.com\">Website</a></li>\n<li> <a href=\"https://www.advancedcustomfields.com/resources/\">Documentation</a></li>\n<li> <a href=\"https://support.advancedcustomfields.com\">Support</a></li>\n<li> <a href=\"https://www.advancedcustomfields.com/pro/\">ACF PRO</a></li>\n</ul>\n<h4>PRO</h4>\n<p>The Advanced Custom Fields plugin is also available in a professional version which includes more fields, more functionality, and more flexibility! <a href=\"https://www.advancedcustomfields.com/pro/\">Learn more</a></p>\n\";s:12:\"installation\";s:508:\"<p>From your WordPress dashboard</p>\n<ol>\n<li> <strong>Visit</strong> Plugins > Add New</li>\n<li> <strong>Search</strong> for \"Advanced Custom Fields\"</li>\n<li> <strong>Activate</strong> Advanced Custom Fields from your Plugins page</li>\n<li> <strong>Click</strong> on the new menu item \"Custom Fields\" and create your first Custom Field Group!</li>\n<li> <strong>Read</strong> the documentation to <a href=\"https://www.advancedcustomfields.com/resources/getting-started-with-acf/\">get started</a></li>\n</ol>\n\";s:9:\"changelog\";s:8401:\"<h4>5.8.3</h4>\n<p><em>Release Date - 7 August 2019</em></p>\n<ul>\n<li> Tweak - Changed Options Page location rules to show \"page_title\" instead of \"menu_title\".</li>\n<li> Fix - Fixed bug causing Textarea field to incorrectly validate maxlength.</li>\n<li> Fix - Fixed bug allowing Range field values outside of the min and max settings.</li>\n<li> Fix - Fixed bug in block RegExp causing some blocks to miss the \"acf/pre_save_block\" filter.</li>\n<li> Dev - Added <code>$block_type</code> parameter to block settings \"enqueue_assets\" callback.</li>\n<li> i18n - Added French Canadian language thanks to Bérenger Zyla.</li>\n<li> i18n - Updated French language thanks to Bérenger Zyla.</li>\n</ul>\n<h4>5.8.2</h4>\n<p><em>Release Date - 15 July 2019</em></p>\n<ul>\n<li> Fix - Fixed bug where validation did not prevent new user registration.</li>\n<li> Fix - Fixed bug causing some \"reordered\" metaboxes to not appear in the Gutenberg editor.</li>\n<li> Fix - Fixed bug causing WYSIWYG field with delayed initialization to appear blank.</li>\n<li> Fix - Fixed bug when editing a post and adding a new tag did not refresh metaboxes.</li>\n<li> Dev - Added missing <code>$value</code> parameter in \"acf/pre_format_value\" filter.</li>\n</ul>\n<h4>5.8.1</h4>\n<p><em>Release Date - 3 June 2019</em></p>\n<ul>\n<li> New - Added \"Preview Size\" and \"Return Format\" settings to the Gallery field.</li>\n<li> Tweak - Improved metabox styling for Gutenberg.</li>\n<li> Tweak - Changed default \"Preview Size\" to medium for the Image field.</li>\n<li> Fix - Fixed bug in media modal causing the primary button text to disappear after editing an image.</li>\n<li> Fix - Fixed bug preventing the TinyMCE Advanced plugin from adding <code>< p ></code> tags.</li>\n<li> Fix - Fixed bug where HTML choices were not visible in conditional logic dropdown.</li>\n<li> Fix - Fixed bug causing incorrect order of imported/synced flexible content sub fields.</li>\n<li> i18n - Updated German translation thanks to Ralf Koller.</li>\n<li> i18n - Updated Persian translation thanks to Majix.</li>\n</ul>\n<h4>5.8.0</h4>\n<p><em>Release Date - 8 May 2019</em></p>\n<ul>\n<li> New - Added ACF Blocks feature for ACF PRO.</li>\n<li> Fix - Fixed bug causing duplicate \"save metabox\" AJAX requests in the Gutenberg editor.</li>\n<li> Fix - Fixed bug causing incorrect Repeater field value order in AJAX requests.</li>\n<li> Dev - Added JS filter <code>\'relationship_ajax_data\'</code> to customize Relationship field AJAX data.</li>\n<li> Dev - Added <code>$field_group</code> parameter to <code>\'acf/location/match_rule\'</code> filter.</li>\n<li> Dev - Bumped minimum supported PHP version to 5.4.0.</li>\n<li> Dev - Bumped minimum supported WP version to 4.7.0.</li>\n<li> i18n - Updated German translation thanks to Ralf Koller.</li>\n<li> i18n - Updated Portuguese language thanks to Pedro Mendonça.</li>\n</ul>\n<h4>5.7.13</h4>\n<p><em>Release Date - 6 March 2019</em></p>\n<ul>\n<li> Fix - Fixed bug causing issues with registered fields during <code>switch_to_blog()</code>.</li>\n<li> Fix - Fixed bug preventing sub fields from being reused across multiple parents.</li>\n<li> Fix - Fixed bug causing the <code>get_sub_field()</code> function to fail if a tab field exists with the same name as the selected field.</li>\n<li> Fix - Fixed bug corrupting field settings since WP 5.1 when instructions contain <code>< a target=\"\" ></code>.</li>\n<li> Fix - Fixed bug in Gutenberg where custom metabox location (acf_after_title) did not show on initial page load.</li>\n<li> Fix - Fixed bug causing issues when importing/syncing multiple field groups which contain a clone field.</li>\n<li> Fix - Fixed bug preventing the AMP plugin preview from working.</li>\n<li> Dev - Added new \'pre\' filters to get, update and delete meta functions.</li>\n<li> i18n - Update Turkish translation thanks to Emre Erkan.</li>\n</ul>\n<h4>5.7.12</h4>\n<p><em>Release Date - 15 February 2019</em></p>\n<ul>\n<li> Fix - Added missing function <code>register_field_group()</code>.</li>\n<li> Fix - Fixed PHP 5.4 error \"Can\'t use function return value in write context\".</li>\n<li> Fix - Fixed bug causing wp_options values to be slashed incorrectly.</li>\n<li> Fix - Fixed bug where \"sync\" feature imported field groups without fields.</li>\n<li> Fix - Fixed bug preventing <code>get_field_object()</code> working with a field key.</li>\n<li> Fix - Fixed bug causing incorrect results in <code>get_sub_field()</code>.</li>\n<li> Fix - Fixed bug causing draft and preview issues with serialized values.</li>\n<li> Fix - Fixed bug causing reversed field group metabox order.</li>\n<li> Fix - Fixed bug causing incorrect character count when validating values.</li>\n<li> Fix - Fixed bug showing incorrect choices for post_template location rule.</li>\n<li> Fix - Fixed bug causing incorrect value retrieval after <code>switch_to_blog()</code>.</li>\n<li> i18n - Updated Persian translation thanks to Majix.</li>\n</ul>\n<h4>5.7.11</h4>\n<p><em>Release Date - 11 February 2019</em></p>\n<ul>\n<li> New - Added support for persistent object caching.</li>\n<li> Fix - Fixed PHP error in <code>determine_locale()</code> affecting AJAX requests.</li>\n<li> Fix - Fixed bug affecting dynamic metabox check when selecting \"default\" page template.</li>\n<li> Fix - Fixed bug where tab fields did not render correctly within a dynamic metabox.</li>\n<li> Tweak - Removed language fallback from \"zh_TW\" to \"zh_CN\".</li>\n<li> Dev - Refactored various core functions.</li>\n<li> Dev - Added new hook variation functions <code>acf_add_filter_variations()</code> and <code>acf_add_action_variations()</code>.</li>\n<li> i18n - Updated Portuguese language thanks to Pedro Mendonça.</li>\n<li> i18n - Updated German translation thanks to Ralf Koller.</li>\n<li> i18n - Updated Swiss German translation thanks to Raphael Hüni.</li>\n</ul>\n<h4>5.7.10</h4>\n<p><em>Release Date - 16 January 2019</em></p>\n<ul>\n<li> Fix - Fixed bug preventing metaboxes from saving if validation fails within Gutenberg.</li>\n<li> Fix - Fixed bug causing unload prompt to show incorrectly within Gutenberg.</li>\n<li> Fix - Fixed JS error when selecting taxonomy terms within Gutenberg.</li>\n<li> Fix - Fixed bug causing jQuery sortable issues within other plugins.</li>\n<li> Tweak - Improved loading translations by adding fallback from region to country when .mo file does not exit.</li>\n<li> Tweak - Improved punctuation throughout admin notices.</li>\n<li> Tweak - Improved performance and accuracy when loading a user field value.</li>\n<li> Dev - Added filter \'acf/get_locale\' to customize the locale used to load translations.</li>\n<li> Dev - Added filter \'acf/allow_unfiltered_html\' to customize if current user can save unfiltered HTML.</li>\n<li> Dev - Added new data storage functions <code>acf_register_store()</code> and <code>acf_get_store()</code>.</li>\n<li> Dev - Moved from .less to .scss and minified all css.</li>\n<li> i18n - Updated French translation thanks to Maxime Bernard-Jacquet.</li>\n<li> i18n - Updated Czech translation thanks to David Rychly.</li>\n</ul>\n<h4>5.7.9</h4>\n<p><em>Release Date - 17 December 2018</em></p>\n<ul>\n<li> Fix - Added custom metabox location (acf_after_title) compatibility with Gutenberg.</li>\n<li> Fix - Added dynamic metabox check compatibility with Gutenberg.</li>\n<li> Fix - Fixed bug causing required date picker fields to prevent form submit.</li>\n<li> Fix - Fixed bug preventing multi-input values from saving correctly within media modals.</li>\n<li> Fix - Fixed bug where <code>acf_form()</code> redirects to an incorrect URL for sub-sites.</li>\n<li> Fix - Fixed bug where breaking out of a sub <code>have_rows()</code> loop could produce undesired results.</li>\n<li> Dev - Added filter \'acf/connect_attachment_to_post\' to prevent connecting attachments to posts.</li>\n<li> Dev - Added JS filter \'google_map_autocomplete_args\' to customize Google Maps autocomplete settings.</li>\n</ul>\n<h4>5.7.8</h4>\n<p><em>Release Date - 7 December 2018</em></p>\n<ul>\n<li> Fix - Fixed vulnerability allowing author role to save unfiltered HTML values.</li>\n<li> Fix - Fixed all metaboxes appearing when editing a post in WP 5.0.</li>\n<li> i18n - Updated Polish translation thanks to Dariusz Zielonka.</li>\n<li> i18n - Updated Czech translation thanks to Veronika Hanzlíková.</li>\n<li> i18n - Update Turkish translation thanks to Emre Erkan.</li>\n<li> i18n - Updated Portuguese language thanks to Pedro Mendonça.</li>\n</ul>\n\";s:14:\"upgrade_notice\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}}', 'no'),
(546, '_site_transient_timeout_theme_roots', '1567430628', 'no'),
(547, '_site_transient_theme_roots', 'a:2:{s:3:\"mis\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";}', 'no'),
(548, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1567428830;s:7:\"checked\";a:6:{s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"5.3.7\";s:43:\"custom-post-type-ui/custom-post-type-ui.php\";s:5:\"1.6.2\";s:48:\"custom-list-table-example/list-table-example.php\";s:5:\"1.4.1\";s:37:\"post-types-order/post-types-order.php\";s:7:\"1.9.4.1\";s:37:\"user-role-editor/user-role-editor.php\";s:6:\"4.51.2\";s:56:\"wp-front-end-login-and-register/wp-mp-register-login.php\";s:5:\"2.1.0\";}s:8:\"response\";a:2:{s:37:\"user-role-editor/user-role-editor.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:30:\"w.org/plugins/user-role-editor\";s:4:\"slug\";s:16:\"user-role-editor\";s:6:\"plugin\";s:37:\"user-role-editor/user-role-editor.php\";s:11:\"new_version\";s:6:\"4.51.3\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/user-role-editor/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/user-role-editor.4.51.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/user-role-editor/assets/icon-256x256.jpg?rev=1020390\";s:2:\"1x\";s:69:\"https://ps.w.org/user-role-editor/assets/icon-128x128.jpg?rev=1020390\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:71:\"https://ps.w.org/user-role-editor/assets/banner-772x250.png?rev=1263116\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.2\";s:12:\"requires_php\";s:3:\"5.5\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:34:\"advanced-custom-fields-pro/acf.php\";O:8:\"stdClass\":5:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:5:\"5.8.3\";s:3:\"url\";s:36:\"https://www.advancedcustomfields.com\";s:7:\"package\";s:0:\"\";}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:4:{s:43:\"custom-post-type-ui/custom-post-type-ui.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:33:\"w.org/plugins/custom-post-type-ui\";s:4:\"slug\";s:19:\"custom-post-type-ui\";s:6:\"plugin\";s:43:\"custom-post-type-ui/custom-post-type-ui.php\";s:11:\"new_version\";s:5:\"1.6.2\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/custom-post-type-ui/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/custom-post-type-ui.1.6.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/custom-post-type-ui/assets/icon-256x256.png?rev=1069557\";s:2:\"1x\";s:72:\"https://ps.w.org/custom-post-type-ui/assets/icon-128x128.png?rev=1069557\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/custom-post-type-ui/assets/banner-1544x500.png?rev=1069557\";s:2:\"1x\";s:74:\"https://ps.w.org/custom-post-type-ui/assets/banner-772x250.png?rev=1069557\";}s:11:\"banners_rtl\";a:0:{}}s:48:\"custom-list-table-example/list-table-example.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:39:\"w.org/plugins/custom-list-table-example\";s:4:\"slug\";s:25:\"custom-list-table-example\";s:6:\"plugin\";s:48:\"custom-list-table-example/list-table-example.php\";s:11:\"new_version\";s:5:\"1.4.1\";s:3:\"url\";s:56:\"https://wordpress.org/plugins/custom-list-table-example/\";s:7:\"package\";s:74:\"https://downloads.wordpress.org/plugin/custom-list-table-example.1.4.1.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:69:\"https://s.w.org/plugins/geopattern-icon/custom-list-table-example.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:37:\"post-types-order/post-types-order.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:30:\"w.org/plugins/post-types-order\";s:4:\"slug\";s:16:\"post-types-order\";s:6:\"plugin\";s:37:\"post-types-order/post-types-order.php\";s:11:\"new_version\";s:7:\"1.9.4.1\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/post-types-order/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/post-types-order.1.9.4.1.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:69:\"https://ps.w.org/post-types-order/assets/icon-128x128.png?rev=1226428\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/post-types-order/assets/banner-1544x500.png?rev=1675574\";s:2:\"1x\";s:71:\"https://ps.w.org/post-types-order/assets/banner-772x250.png?rev=1429949\";}s:11:\"banners_rtl\";a:0:{}}s:56:\"wp-front-end-login-and-register/wp-mp-register-login.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:45:\"w.org/plugins/wp-front-end-login-and-register\";s:4:\"slug\";s:31:\"wp-front-end-login-and-register\";s:6:\"plugin\";s:56:\"wp-front-end-login-and-register/wp-mp-register-login.php\";s:11:\"new_version\";s:5:\"2.1.0\";s:3:\"url\";s:62:\"https://wordpress.org/plugins/wp-front-end-login-and-register/\";s:7:\"package\";s:74:\"https://downloads.wordpress.org/plugin/wp-front-end-login-and-register.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:84:\"https://ps.w.org/wp-front-end-login-and-register/assets/icon-128x128.png?rev=1717377\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:86:\"https://ps.w.org/wp-front-end-login-and-register/assets/banner-772x250.png?rev=1717370\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 3, '_wp_page_template', 'default'),
(3, 1, '_wp_trash_meta_status', 'publish'),
(4, 1, '_wp_trash_meta_time', '1565008551'),
(5, 1, '_wp_desired_post_slug', 'hello-world'),
(6, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:\"1\";}'),
(7, 6, '_edit_last', '1'),
(8, 6, '_edit_lock', '1565603171:1'),
(9, 7, '_edit_last', '1'),
(10, 7, '_edit_lock', '1565009741:1'),
(11, 8, '_edit_last', '1'),
(12, 8, '_edit_lock', '1565009748:1'),
(13, 9, '_edit_last', '1'),
(14, 9, '_edit_lock', '1565009758:1'),
(15, 10, '_edit_last', '1'),
(16, 10, '_edit_lock', '1565009765:1'),
(17, 11, '_edit_last', '1'),
(18, 11, '_edit_lock', '1565009771:1'),
(19, 12, '_edit_last', '1'),
(20, 12, '_edit_lock', '1565009798:1'),
(21, 12, '_wp_old_slug', 'question-4-2'),
(22, 13, '_edit_last', '1'),
(23, 13, '_edit_lock', '1565009806:1'),
(24, 14, '_edit_last', '1'),
(25, 14, '_edit_lock', '1565009813:1'),
(26, 15, '_edit_last', '1'),
(27, 15, '_edit_lock', '1565009820:1'),
(28, 16, '_edit_last', '1'),
(29, 16, '_edit_lock', '1565009827:1'),
(30, 18, '_edit_last', '1'),
(31, 18, '_edit_lock', '1567145832:1'),
(32, 21, '_edit_last', '1'),
(33, 21, '_edit_lock', '1566904975:1'),
(34, 27, '_edit_last', '1'),
(35, 27, '_edit_lock', '1567142180:1'),
(36, 38, 'agencies_0_option', 'Microsoft'),
(37, 38, '_agencies_0_option', 'field_5d482d954d9c0'),
(38, 38, 'agencies_1_option', 'Apple'),
(39, 38, '_agencies_1_option', 'field_5d482d954d9c0'),
(40, 38, 'agencies_2_option', 'Linux'),
(41, 38, '_agencies_2_option', 'field_5d482d954d9c0'),
(42, 38, 'agencies', '3'),
(43, 38, '_agencies', 'field_5d482d2e32f53'),
(44, 38, 'hardware_0_option', 'CPU'),
(45, 38, '_hardware_0_option', 'field_5d4bc17555d8e'),
(46, 38, 'hardware_1_option', 'Keyboard'),
(47, 38, '_hardware_1_option', 'field_5d4bc17555d8e'),
(48, 38, 'hardware_2_option', 'Mouse'),
(49, 38, '_hardware_2_option', 'field_5d4bc17555d8e'),
(50, 38, 'hardware', '3'),
(51, 38, '_hardware', 'field_5d482ee02748c'),
(52, 38, 'os_0_option', 'Windows'),
(53, 38, '_os_0_option', 'field_5d4bc1e255d90'),
(54, 38, 'os_1_option', 'Mac'),
(55, 38, '_os_1_option', 'field_5d4bc1e255d90'),
(56, 38, 'os_2_option', 'Ubantu'),
(57, 38, '_os_2_option', 'field_5d4bc1e255d90'),
(58, 38, 'os', '3'),
(59, 38, '_os', 'field_5d4bc18355d8f'),
(60, 38, 'environment_types_0_option', 'Live'),
(61, 38, '_environment_types_0_option', 'field_5d4bc20955d92'),
(62, 38, 'environment_types_1_option', 'Local'),
(63, 38, '_environment_types_1_option', 'field_5d4bc20955d92'),
(64, 38, 'environment_types', '2'),
(65, 38, '_environment_types', 'field_5d4bc1ec55d91'),
(66, 38, 'programming_languages_0_option', 'PHP'),
(67, 38, '_programming_languages_0_option', 'field_5d4bc23f55d94'),
(68, 38, 'programming_languages_1_option', 'C'),
(69, 38, '_programming_languages_1_option', 'field_5d4bc23f55d94'),
(70, 38, 'programming_languages_2_option', 'Java'),
(71, 38, '_programming_languages_2_option', 'field_5d4bc23f55d94'),
(72, 38, 'programming_languages', '3'),
(73, 38, '_programming_languages', 'field_5d4bc22a55d93'),
(74, 38, 'storages_0_option', '10 GB'),
(75, 38, '_storages_0_option', 'field_5d4bc25c55d96'),
(76, 38, 'storages_1_option', '100 GB'),
(77, 38, '_storages_1_option', 'field_5d4bc25c55d96'),
(78, 38, 'storages_2_option', '520 GB'),
(79, 38, '_storages_2_option', 'field_5d4bc25c55d96'),
(80, 38, 'storages', '3'),
(81, 38, '_storages', 'field_5d4bc25055d95'),
(82, 18, 'agencies_0_option', 'Microsoft'),
(83, 18, '_agencies_0_option', 'field_5d482d954d9c0'),
(84, 18, 'agencies_1_option', 'Apple'),
(85, 18, '_agencies_1_option', 'field_5d482d954d9c0'),
(86, 18, 'agencies_2_option', 'Linux'),
(87, 18, '_agencies_2_option', 'field_5d482d954d9c0'),
(88, 18, 'agencies', '4'),
(89, 18, '_agencies', 'field_5d482d2e32f53'),
(90, 18, 'hardware_0_option', 'CPU'),
(91, 18, '_hardware_0_option', 'field_5d4bc17555d8e'),
(92, 18, 'hardware_1_option', 'Keyboard'),
(93, 18, '_hardware_1_option', 'field_5d4bc17555d8e'),
(94, 18, 'hardware_2_option', 'Mouse'),
(95, 18, '_hardware_2_option', 'field_5d4bc17555d8e'),
(96, 18, 'hardware', '3'),
(97, 18, '_hardware', 'field_5d482ee02748c'),
(98, 18, 'os_0_option', 'Windows'),
(99, 18, '_os_0_option', 'field_5d4bc1e255d90'),
(100, 18, 'os_1_option', 'Mac'),
(101, 18, '_os_1_option', 'field_5d4bc1e255d90'),
(102, 18, 'os_2_option', 'Ubantu'),
(103, 18, '_os_2_option', 'field_5d4bc1e255d90'),
(104, 18, 'os', '3'),
(105, 18, '_os', 'field_5d4bc18355d8f'),
(106, 18, 'environment_types_0_option', 'Live'),
(107, 18, '_environment_types_0_option', 'field_5d4bc20955d92'),
(108, 18, 'environment_types_1_option', 'Local'),
(109, 18, '_environment_types_1_option', 'field_5d4bc20955d92'),
(110, 18, 'environment_types', '2'),
(111, 18, '_environment_types', 'field_5d4bc1ec55d91'),
(112, 18, 'programming_languages_0_option', 'PHP'),
(113, 18, '_programming_languages_0_option', 'field_5d4bc23f55d94'),
(114, 18, 'programming_languages_1_option', 'C'),
(115, 18, '_programming_languages_1_option', 'field_5d4bc23f55d94'),
(116, 18, 'programming_languages_2_option', 'Java'),
(117, 18, '_programming_languages_2_option', 'field_5d4bc23f55d94'),
(118, 18, 'programming_languages', '3'),
(119, 18, '_programming_languages', 'field_5d4bc22a55d93'),
(120, 18, 'storages_0_option', '10 GB'),
(121, 18, '_storages_0_option', 'field_5d4bc25c55d96'),
(122, 18, 'storages_1_option', '100 GB'),
(123, 18, '_storages_1_option', 'field_5d4bc25c55d96'),
(124, 18, 'storages_2_option', '520 GB'),
(125, 18, '_storages_2_option', 'field_5d4bc25c55d96'),
(126, 18, 'storages', '3'),
(127, 18, '_storages', 'field_5d4bc25055d95'),
(128, 18, '_wp_page_template', 'page-template/page-assessment.php'),
(129, 39, '_edit_last', '1'),
(130, 39, '_edit_lock', '1565339848:1'),
(131, 39, '_wp_page_template', 'default'),
(132, 41, '_edit_last', '1'),
(133, 41, '_edit_lock', '1565783369:1'),
(134, 41, '_wp_page_template', 'default'),
(135, 43, '_edit_last', '1'),
(136, 43, '_edit_lock', '1565591153:1'),
(137, 43, '_wp_page_template', 'default'),
(138, 27, '_wp_page_template', 'page-template/page-home.php'),
(139, 49, 'agencies_0_option', 'Microsoft'),
(140, 49, '_agencies_0_option', 'field_5d482d954d9c0'),
(141, 49, 'agencies_1_option', 'Apple'),
(142, 49, '_agencies_1_option', 'field_5d482d954d9c0'),
(143, 49, 'agencies_2_option', 'Linux'),
(144, 49, '_agencies_2_option', 'field_5d482d954d9c0'),
(145, 49, 'agencies_3_option', 'Testing'),
(146, 49, '_agencies_3_option', 'field_5d482d954d9c0'),
(147, 49, 'agencies', '4'),
(148, 49, '_agencies', 'field_5d482d2e32f53'),
(149, 49, 'hardware_0_option', 'CPU'),
(150, 49, '_hardware_0_option', 'field_5d4bc17555d8e'),
(151, 49, 'hardware_1_option', 'Keyboard'),
(152, 49, '_hardware_1_option', 'field_5d4bc17555d8e'),
(153, 49, 'hardware_2_option', 'Mouse'),
(154, 49, '_hardware_2_option', 'field_5d4bc17555d8e'),
(155, 49, 'hardware', '3'),
(156, 49, '_hardware', 'field_5d482ee02748c'),
(157, 49, 'os_0_option', 'Windows'),
(158, 49, '_os_0_option', 'field_5d4bc1e255d90'),
(159, 49, 'os_1_option', 'Mac'),
(160, 49, '_os_1_option', 'field_5d4bc1e255d90'),
(161, 49, 'os_2_option', 'Ubantu'),
(162, 49, '_os_2_option', 'field_5d4bc1e255d90'),
(163, 49, 'os', '3'),
(164, 49, '_os', 'field_5d4bc18355d8f'),
(165, 49, 'environment_types_0_option', 'Live'),
(166, 49, '_environment_types_0_option', 'field_5d4bc20955d92'),
(167, 49, 'environment_types_1_option', 'Local'),
(168, 49, '_environment_types_1_option', 'field_5d4bc20955d92'),
(169, 49, 'environment_types', '2'),
(170, 49, '_environment_types', 'field_5d4bc1ec55d91'),
(171, 49, 'programming_languages_0_option', 'PHP'),
(172, 49, '_programming_languages_0_option', 'field_5d4bc23f55d94'),
(173, 49, 'programming_languages_1_option', 'C'),
(174, 49, '_programming_languages_1_option', 'field_5d4bc23f55d94'),
(175, 49, 'programming_languages_2_option', 'Java'),
(176, 49, '_programming_languages_2_option', 'field_5d4bc23f55d94'),
(177, 49, 'programming_languages', '3'),
(178, 49, '_programming_languages', 'field_5d4bc22a55d93'),
(179, 49, 'storages_0_option', '10 GB'),
(180, 49, '_storages_0_option', 'field_5d4bc25c55d96'),
(181, 49, 'storages_1_option', '100 GB'),
(182, 49, '_storages_1_option', 'field_5d4bc25c55d96'),
(183, 49, 'storages_2_option', '520 GB'),
(184, 49, '_storages_2_option', 'field_5d4bc25c55d96'),
(185, 49, 'storages', '3'),
(186, 49, '_storages', 'field_5d4bc25055d95'),
(187, 18, 'agencies_3_option', 'Testing'),
(188, 18, '_agencies_3_option', 'field_5d482d954d9c0'),
(197, 55, '_edit_lock', '1566012116:1'),
(198, 55, '_edit_last', '1'),
(199, 59, '_edit_lock', '1566012178:1'),
(200, 59, '_edit_last', '1'),
(201, 63, '_wp_attached_file', '2019/08/logo.png'),
(202, 63, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:90;s:6:\"height\";i:60;s:4:\"file\";s:16:\"2019/08/logo.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(203, 64, '_wp_attached_file', '2019/08/img-features-survey.png'),
(204, 64, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:490;s:6:\"height\";i:179;s:4:\"file\";s:31:\"2019/08/img-features-survey.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"img-features-survey-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"img-features-survey-300x110.png\";s:5:\"width\";i:300;s:6:\"height\";i:110;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(205, 65, '_wp_attached_file', '2019/08/490x180.png'),
(206, 65, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:490;s:6:\"height\";i:180;s:4:\"file\";s:19:\"2019/08/490x180.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"490x180-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"490x180-300x110.png\";s:5:\"width\";i:300;s:6:\"height\";i:110;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(207, 66, 'features_0_title', 'Survey'),
(208, 66, '_features_0_title', 'field_5d57737aa4715'),
(209, 66, 'features_0_image', '64'),
(210, 66, '_features_0_image', 'field_5d577385a4716'),
(211, 66, 'features_1_title', 'Reporting'),
(212, 66, '_features_1_title', 'field_5d57737aa4715'),
(213, 66, 'features_1_image', '65'),
(214, 66, '_features_1_image', 'field_5d577385a4716'),
(215, 66, 'features_2_title', 'Engagement'),
(216, 66, '_features_2_title', 'field_5d57737aa4715'),
(217, 66, 'features_2_image', '65'),
(218, 66, '_features_2_image', 'field_5d577385a4716'),
(219, 66, 'features', '3'),
(220, 66, '_features', 'field_5d57736ca4714'),
(221, 27, 'features_0_title', 'Survey'),
(222, 27, '_features_0_title', 'field_5d57737aa4715'),
(223, 27, 'features_0_image', '64'),
(224, 27, '_features_0_image', 'field_5d577385a4716'),
(225, 27, 'features_1_title', 'Reporting'),
(226, 27, '_features_1_title', 'field_5d57737aa4715'),
(227, 27, 'features_1_image', '65'),
(228, 27, '_features_1_image', 'field_5d577385a4716'),
(229, 27, 'features_2_title', 'Engagement'),
(230, 27, '_features_2_title', 'field_5d57737aa4715'),
(231, 27, 'features_2_image', '65'),
(232, 27, '_features_2_image', 'field_5d577385a4716'),
(233, 27, 'features', '3'),
(234, 27, '_features', 'field_5d57736ca4714'),
(235, 68, 'features_0_title', 'Survey'),
(236, 68, '_features_0_title', 'field_5d57737aa4715'),
(237, 68, 'features_0_image', '64'),
(238, 68, '_features_0_image', 'field_5d577385a4716'),
(239, 68, 'features_1_title', 'Reporting'),
(240, 68, '_features_1_title', 'field_5d57737aa4715'),
(241, 68, 'features_1_image', '65'),
(242, 68, '_features_1_image', 'field_5d577385a4716'),
(243, 68, 'features_2_title', 'Engagement'),
(244, 68, '_features_2_title', 'field_5d57737aa4715'),
(245, 68, 'features_2_image', '65'),
(246, 68, '_features_2_image', 'field_5d577385a4716'),
(247, 68, 'features', '3'),
(248, 68, '_features', 'field_5d57736ca4714'),
(249, 69, 'organizations_0_option', 'Option 1'),
(250, 69, '_organizations_0_option', 'field_5d482d954d9c0'),
(251, 69, 'organizations_1_option', 'Option 2'),
(252, 69, '_organizations_1_option', 'field_5d482d954d9c0'),
(253, 69, 'organizations_2_option', 'Option 3'),
(254, 69, '_organizations_2_option', 'field_5d482d954d9c0'),
(255, 69, 'organizations', '3'),
(256, 69, '_organizations', 'field_5d482d2e32f53'),
(257, 69, 'hardware_0_option', 'CPU'),
(258, 69, '_hardware_0_option', 'field_5d4bc17555d8e'),
(259, 69, 'hardware_1_option', 'Keyboard'),
(260, 69, '_hardware_1_option', 'field_5d4bc17555d8e'),
(261, 69, 'hardware_2_option', 'Mouse'),
(262, 69, '_hardware_2_option', 'field_5d4bc17555d8e'),
(263, 69, 'hardware', '3'),
(264, 69, '_hardware', 'field_5d482ee02748c'),
(265, 69, 'os_0_option', 'Windows'),
(266, 69, '_os_0_option', 'field_5d4bc1e255d90'),
(267, 69, 'os_1_option', 'Mac'),
(268, 69, '_os_1_option', 'field_5d4bc1e255d90'),
(269, 69, 'os_2_option', 'Ubantu'),
(270, 69, '_os_2_option', 'field_5d4bc1e255d90'),
(271, 69, 'os', '3'),
(272, 69, '_os', 'field_5d4bc18355d8f'),
(273, 69, 'environment_types_0_option', 'Live'),
(274, 69, '_environment_types_0_option', 'field_5d4bc20955d92'),
(275, 69, 'environment_types_1_option', 'Local'),
(276, 69, '_environment_types_1_option', 'field_5d4bc20955d92'),
(277, 69, 'environment_types', '2'),
(278, 69, '_environment_types', 'field_5d4bc1ec55d91'),
(279, 69, 'programming_languages_0_option', 'PHP'),
(280, 69, '_programming_languages_0_option', 'field_5d4bc23f55d94'),
(281, 69, 'programming_languages_1_option', 'C'),
(282, 69, '_programming_languages_1_option', 'field_5d4bc23f55d94'),
(283, 69, 'programming_languages_2_option', 'Java'),
(284, 69, '_programming_languages_2_option', 'field_5d4bc23f55d94'),
(285, 69, 'programming_languages', '3'),
(286, 69, '_programming_languages', 'field_5d4bc22a55d93'),
(287, 69, 'storages_0_option', '10 GB'),
(288, 69, '_storages_0_option', 'field_5d4bc25c55d96'),
(289, 69, 'storages_1_option', '100 GB'),
(290, 69, '_storages_1_option', 'field_5d4bc25c55d96'),
(291, 69, 'storages_2_option', '520 GB'),
(292, 69, '_storages_2_option', 'field_5d4bc25c55d96'),
(293, 69, 'storages', '3'),
(294, 69, '_storages', 'field_5d4bc25055d95'),
(295, 18, 'organizations_0_option', 'Option 1'),
(296, 18, '_organizations_0_option', 'field_5d482d954d9c0'),
(297, 18, 'organizations_1_option', 'Option 2'),
(298, 18, '_organizations_1_option', 'field_5d482d954d9c0'),
(299, 18, 'organizations_2_option', 'Option 3'),
(300, 18, '_organizations_2_option', 'field_5d482d954d9c0'),
(301, 18, 'organizations', '3'),
(302, 18, '_organizations', 'field_5d482d2e32f53'),
(303, 3, '_edit_lock', '1566974388:1'),
(304, 72, 'organizations_0_option', 'Option 1'),
(305, 72, '_organizations_0_option', 'field_5d482d954d9c0'),
(306, 72, 'organizations_1_option', 'Option 2'),
(307, 72, '_organizations_1_option', 'field_5d482d954d9c0'),
(308, 72, 'organizations_2_option', 'Option 3'),
(309, 72, '_organizations_2_option', 'field_5d482d954d9c0'),
(310, 72, 'organizations', '3'),
(311, 72, '_organizations', 'field_5d482d2e32f53'),
(312, 72, 'networks_0_option', 'TS'),
(313, 72, '_networks_0_option', 'field_5d64fd527c4de'),
(314, 72, 'networks_1_option', 'S'),
(315, 72, '_networks_1_option', 'field_5d64fd527c4de'),
(316, 72, 'networks_2_option', 'C'),
(317, 72, '_networks_2_option', 'field_5d64fd527c4de'),
(318, 72, 'networks', '3'),
(319, 72, '_networks', 'field_5d64fd527c4dd'),
(320, 72, 'hardware_0_option', 'CPU'),
(321, 72, '_hardware_0_option', 'field_5d4bc17555d8e'),
(322, 72, 'hardware_1_option', 'Keyboard'),
(323, 72, '_hardware_1_option', 'field_5d4bc17555d8e'),
(324, 72, 'hardware_2_option', 'Mouse'),
(325, 72, '_hardware_2_option', 'field_5d4bc17555d8e'),
(326, 72, 'hardware', '3'),
(327, 72, '_hardware', 'field_5d482ee02748c'),
(328, 72, 'os_0_option', 'Windows'),
(329, 72, '_os_0_option', 'field_5d4bc1e255d90'),
(330, 72, 'os_1_option', 'Mac'),
(331, 72, '_os_1_option', 'field_5d4bc1e255d90'),
(332, 72, 'os_2_option', 'Ubantu'),
(333, 72, '_os_2_option', 'field_5d4bc1e255d90'),
(334, 72, 'os', '3'),
(335, 72, '_os', 'field_5d4bc18355d8f'),
(336, 72, 'environment_types_0_option', 'Live'),
(337, 72, '_environment_types_0_option', 'field_5d4bc20955d92'),
(338, 72, 'environment_types_1_option', 'Local'),
(339, 72, '_environment_types_1_option', 'field_5d4bc20955d92'),
(340, 72, 'environment_types', '2'),
(341, 72, '_environment_types', 'field_5d4bc1ec55d91'),
(342, 72, 'programming_languages_0_option', 'PHP'),
(343, 72, '_programming_languages_0_option', 'field_5d4bc23f55d94'),
(344, 72, 'programming_languages_1_option', 'C'),
(345, 72, '_programming_languages_1_option', 'field_5d4bc23f55d94'),
(346, 72, 'programming_languages_2_option', 'Java'),
(347, 72, '_programming_languages_2_option', 'field_5d4bc23f55d94'),
(348, 72, 'programming_languages', '3'),
(349, 72, '_programming_languages', 'field_5d4bc22a55d93'),
(350, 72, 'storages_0_option', '10 GB'),
(351, 72, '_storages_0_option', 'field_5d4bc25c55d96'),
(352, 72, 'storages_1_option', '100 GB'),
(353, 72, '_storages_1_option', 'field_5d4bc25c55d96'),
(354, 72, 'storages_2_option', '520 GB'),
(355, 72, '_storages_2_option', 'field_5d4bc25c55d96'),
(356, 72, 'storages', '3'),
(357, 72, '_storages', 'field_5d4bc25055d95'),
(358, 18, 'networks_0_option', 'TS'),
(359, 18, '_networks_0_option', 'field_5d64fd527c4de'),
(360, 18, 'networks_1_option', 'S'),
(361, 18, '_networks_1_option', 'field_5d64fd527c4de'),
(362, 18, 'networks_2_option', 'C'),
(363, 18, '_networks_2_option', 'field_5d64fd527c4de'),
(364, 18, 'networks', '3'),
(365, 18, '_networks', 'field_5d64fd527c4dd'),
(366, 73, '_edit_lock', '1566908139:1'),
(367, 73, '_edit_last', '1'),
(368, 73, '_wp_page_template', 'page-template/page-reports.php'),
(372, 75, '_edit_lock', '1567077096:1'),
(373, 75, '_edit_last', '1'),
(374, 75, '_wp_page_template', 'page-template/page-project-details.php'),
(375, 77, '_edit_lock', '1567141969:1'),
(376, 77, '_edit_last', '1'),
(377, 77, '_wp_page_template', 'page-template/page-project-edit.php'),
(378, 79, '_edit_last', '1'),
(379, 79, '_wp_page_template', 'page-template/page-project-delete.php'),
(380, 79, '_edit_lock', '1567141758:1'),
(381, 3, '_edit_last', '1'),
(382, 83, '_edit_lock', '1567244746:1'),
(383, 83, '_edit_last', '1'),
(384, 83, '_wp_page_template', 'page-template/page-project-action.php');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-08-05 12:35:22', '2019-08-05 12:35:22', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2019-08-05 12:35:51', '2019-08-05 12:35:51', '', 0, 'http://localhost/wp/mis/?p=1', 0, 'post', '', 1),
(3, 1, '2019-08-05 12:35:22', '2019-08-05 12:35:22', '<h2>Who we are</h2>\r\nOur website address is: http://localhost/wp/mis.\r\n<h2>What personal data we collect and why we collect it</h2>\r\n<h3>Comments</h3>\r\nWhen visitors leave comments on the site we collect the data shown in the comments form, and also the visitor’s IP address and browser user agent string to help spam detection.\r\n\r\nAn anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.\r\n<h3>Media</h3>\r\nIf you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.\r\n<h3>Contact forms</h3>\r\n<h3>Cookies</h3>\r\nIf you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.\r\n\r\nIf you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.\r\n\r\nWhen you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select \"Remember Me\", your login will persist for two weeks. If you log out of your account, the login cookies will be removed.\r\n\r\nIf you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.\r\n<h3>Embedded content from other websites</h3>\r\nArticles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.\r\n\r\nThese websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.\r\n<h3>Analytics</h3>\r\n<h2>Who we share your data with</h2>\r\n<h2>How long we retain your data</h2>\r\nIf you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.\r\n\r\nFor users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.\r\n<h2>What rights you have over your data</h2>\r\nIf you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.\r\n<h2>Where we send your data</h2>\r\nVisitor comments may be checked through an automated spam detection service.\r\n<h2>Your contact information</h2>\r\n<h2>Additional information</h2>\r\n<h3>How we protect your data</h3>\r\n<h3>What data breach procedures we have in place</h3>\r\n<h3>What third parties we receive data from</h3>\r\n<h3>What automated decision making and/or profiling we do with user data</h3>\r\n<h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'publish', 'closed', 'open', '', 'privacy-policy', '', '', '2019-08-28 06:42:10', '2019-08-28 06:42:10', '', 0, 'http://localhost/wp/mis/?page_id=3', 0, 'page', '', 0),
(5, 1, '2019-08-05 12:35:51', '2019-08-05 12:35:51', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-08-05 12:35:51', '2019-08-05 12:35:51', '', 1, 'http://localhost/wp/mis/2019/08/05/1-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2019-08-05 12:57:27', '2019-08-05 12:57:27', '', 'Question 1', '', 'publish', 'closed', 'closed', '', 'question-1', '', '', '2019-08-05 12:57:27', '2019-08-05 12:57:27', '', 0, 'http://localhost/wp/mis/?post_type=question&#038;p=6', 0, 'question', '', 0),
(7, 1, '2019-08-05 12:58:03', '2019-08-05 12:58:03', '', 'Question 2', '', 'publish', 'closed', 'closed', '', 'question-2', '', '', '2019-08-05 12:58:03', '2019-08-05 12:58:03', '', 0, 'http://localhost/wp/mis/?post_type=question&#038;p=7', 1, 'question', '', 0),
(8, 1, '2019-08-05 12:58:10', '2019-08-05 12:58:10', '', 'Question 3', '', 'publish', 'closed', 'closed', '', 'question-3', '', '', '2019-08-05 12:58:10', '2019-08-05 12:58:10', '', 0, 'http://localhost/wp/mis/?post_type=question&#038;p=8', 2, 'question', '', 0),
(9, 1, '2019-08-05 12:58:18', '2019-08-05 12:58:18', '', 'Question 4', '', 'publish', 'closed', 'closed', '', 'question-4', '', '', '2019-08-05 12:58:18', '2019-08-05 12:58:18', '', 0, 'http://localhost/wp/mis/?post_type=question&#038;p=9', 3, 'question', '', 0),
(10, 1, '2019-08-05 12:58:27', '2019-08-05 12:58:27', '', 'Question 5', '', 'publish', 'closed', 'closed', '', 'question-5', '', '', '2019-08-05 12:58:27', '2019-08-05 12:58:27', '', 0, 'http://localhost/wp/mis/?post_type=question&#038;p=10', 4, 'question', '', 0),
(11, 1, '2019-08-05 12:58:34', '2019-08-05 12:58:34', '', 'Question 6', '', 'publish', 'closed', 'closed', '', 'question-6', '', '', '2019-08-05 12:58:34', '2019-08-05 12:58:34', '', 0, 'http://localhost/wp/mis/?post_type=question&#038;p=11', 5, 'question', '', 0),
(12, 1, '2019-08-05 12:58:50', '2019-08-05 12:58:50', '', 'Question 7', '', 'publish', 'closed', 'closed', '', 'question-7', '', '', '2019-08-05 12:58:59', '2019-08-05 12:58:59', '', 0, 'http://localhost/wp/mis/?post_type=question&#038;p=12', 6, 'question', '', 0),
(13, 1, '2019-08-05 12:59:09', '2019-08-05 12:59:09', '', 'Question 8', '', 'publish', 'closed', 'closed', '', 'question-8', '', '', '2019-08-05 12:59:09', '2019-08-05 12:59:09', '', 0, 'http://localhost/wp/mis/?post_type=question&#038;p=13', 7, 'question', '', 0),
(14, 1, '2019-08-05 12:59:16', '2019-08-05 12:59:16', '', 'Question 9', '', 'publish', 'closed', 'closed', '', 'question-9', '', '', '2019-08-05 12:59:16', '2019-08-05 12:59:16', '', 0, 'http://localhost/wp/mis/?post_type=question&#038;p=14', 8, 'question', '', 0),
(15, 1, '2019-08-05 12:59:22', '2019-08-05 12:59:22', '', 'Question 10', '', 'publish', 'closed', 'closed', '', 'question-10', '', '', '2019-08-05 12:59:22', '2019-08-05 12:59:22', '', 0, 'http://localhost/wp/mis/?post_type=question&#038;p=15', 9, 'question', '', 0),
(16, 1, '2019-08-05 12:59:29', '2019-08-05 12:59:29', '', 'Question 11', '', 'publish', 'closed', 'closed', '', 'question-11', '', '', '2019-08-05 12:59:29', '2019-08-05 12:59:29', '', 0, 'http://localhost/wp/mis/?post_type=question&#038;p=16', 10, 'question', '', 0),
(18, 1, '2019-08-05 13:06:11', '2019-08-05 13:06:11', '', 'Assessment', '', 'publish', 'closed', 'closed', '', 'assessment', '', '', '2019-08-27 09:52:53', '2019-08-27 09:52:53', '', 0, 'http://localhost/wp/mis/?page_id=18', 0, 'page', '', 0),
(19, 1, '2019-08-05 13:06:11', '2019-08-05 13:06:11', '', 'Assessment', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2019-08-05 13:06:11', '2019-08-05 13:06:11', '', 18, 'http://localhost/wp/mis/2019/08/05/18-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2019-08-05 13:09:59', '2019-08-05 13:09:59', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"18\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Assessment Page Fields', 'assessment-page-fields', 'publish', 'closed', 'closed', '', 'group_5d482a91c26fe', '', '', '2019-08-27 09:52:28', '2019-08-27 09:52:28', '', 0, 'http://localhost/wp/mis/?post_type=acf-field-group&#038;p=21', 0, 'acf-field-group', '', 0),
(24, 1, '2019-08-05 13:21:34', '2019-08-05 13:21:34', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:7:\"Add Row\";}', 'Organizations', 'organizations', 'publish', 'closed', 'closed', '', 'field_5d482d2e32f53', '', '', '2019-08-27 09:48:13', '2019-08-27 09:48:13', '', 21, 'http://localhost/wp/mis/?post_type=acf-field&#038;p=24', 0, 'acf-field', '', 0),
(25, 1, '2019-08-05 13:23:03', '2019-08-05 13:23:03', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Option', 'option', 'publish', 'closed', 'closed', '', 'field_5d482d954d9c0', '', '', '2019-08-08 06:34:55', '2019-08-08 06:34:55', '', 24, 'http://localhost/wp/mis/?post_type=acf-field&#038;p=25', 0, 'acf-field', '', 0),
(26, 1, '2019-08-05 13:28:33', '2019-08-05 13:28:33', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:7:\"Add Row\";}', 'Hardware', 'hardware', 'publish', 'closed', 'closed', '', 'field_5d482ee02748c', '', '', '2019-08-27 09:52:28', '2019-08-27 09:52:28', '', 21, 'http://localhost/wp/mis/?post_type=acf-field&#038;p=26', 2, 'acf-field', '', 0),
(27, 1, '2019-08-08 06:29:12', '2019-08-08 06:29:12', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam et interdum purus. Phasellus nec mi ac <strong>tellus</strong> faucibus cursus quis venenatis enim. Sed volutpat est sit amet sagittis vehicula. Phasellus cursus pharetra pellentesque. <a href=\"#\">Nunc</a> hendrerit urna ultricies, egestas orci et, auctor massa. Mauris facilisis leo sit amet elit iaculis pulvinar. Vestibulum id blandit tortor.\r\n<ul>\r\n 	<li>Lorem ipsum dolor sit amet</li>\r\n 	<li>Etiam et interdum</li>\r\n</ul>', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-08-27 09:28:19', '2019-08-27 09:28:19', '', 0, 'http://localhost/wp/mis/?page_id=27', 0, 'page', '', 0),
(28, 1, '2019-08-08 06:29:12', '2019-08-08 06:29:12', '', 'HOME', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2019-08-08 06:29:12', '2019-08-08 06:29:12', '', 27, 'http://localhost/wp/mis/27-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2019-08-08 06:34:55', '2019-08-08 06:34:55', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Option', 'option', 'publish', 'closed', 'closed', '', 'field_5d4bc17555d8e', '', '', '2019-08-08 06:34:55', '2019-08-08 06:34:55', '', 26, 'http://localhost/wp/mis/?post_type=acf-field&p=29', 0, 'acf-field', '', 0),
(30, 1, '2019-08-08 06:34:55', '2019-08-08 06:34:55', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:7:\"Add Row\";}', 'OS', 'os', 'publish', 'closed', 'closed', '', 'field_5d4bc18355d8f', '', '', '2019-08-27 09:52:28', '2019-08-27 09:52:28', '', 21, 'http://localhost/wp/mis/?post_type=acf-field&#038;p=30', 3, 'acf-field', '', 0),
(31, 1, '2019-08-08 06:34:55', '2019-08-08 06:34:55', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Option', 'option', 'publish', 'closed', 'closed', '', 'field_5d4bc1e255d90', '', '', '2019-08-08 06:34:55', '2019-08-08 06:34:55', '', 30, 'http://localhost/wp/mis/?post_type=acf-field&p=31', 0, 'acf-field', '', 0),
(32, 1, '2019-08-08 06:34:55', '2019-08-08 06:34:55', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:7:\"Add Row\";}', 'Environment Types', 'environment_types', 'publish', 'closed', 'closed', '', 'field_5d4bc1ec55d91', '', '', '2019-08-27 09:52:28', '2019-08-27 09:52:28', '', 21, 'http://localhost/wp/mis/?post_type=acf-field&#038;p=32', 4, 'acf-field', '', 0),
(33, 1, '2019-08-08 06:34:55', '2019-08-08 06:34:55', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Option', 'option', 'publish', 'closed', 'closed', '', 'field_5d4bc20955d92', '', '', '2019-08-08 06:34:55', '2019-08-08 06:34:55', '', 32, 'http://localhost/wp/mis/?post_type=acf-field&p=33', 0, 'acf-field', '', 0),
(34, 1, '2019-08-08 06:34:55', '2019-08-08 06:34:55', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:7:\"Add Row\";}', 'Programming languages', 'programming_languages', 'publish', 'closed', 'closed', '', 'field_5d4bc22a55d93', '', '', '2019-08-27 09:52:28', '2019-08-27 09:52:28', '', 21, 'http://localhost/wp/mis/?post_type=acf-field&#038;p=34', 5, 'acf-field', '', 0),
(35, 1, '2019-08-08 06:34:55', '2019-08-08 06:34:55', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Option', 'option', 'publish', 'closed', 'closed', '', 'field_5d4bc23f55d94', '', '', '2019-08-08 06:34:55', '2019-08-08 06:34:55', '', 34, 'http://localhost/wp/mis/?post_type=acf-field&p=35', 0, 'acf-field', '', 0),
(36, 1, '2019-08-08 06:34:55', '2019-08-08 06:34:55', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:7:\"Add Row\";}', 'Storages', 'storages', 'publish', 'closed', 'closed', '', 'field_5d4bc25055d95', '', '', '2019-08-27 09:52:28', '2019-08-27 09:52:28', '', 21, 'http://localhost/wp/mis/?post_type=acf-field&#038;p=36', 6, 'acf-field', '', 0),
(37, 1, '2019-08-08 06:34:55', '2019-08-08 06:34:55', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Option', 'option', 'publish', 'closed', 'closed', '', 'field_5d4bc25c55d96', '', '', '2019-08-08 06:34:55', '2019-08-08 06:34:55', '', 36, 'http://localhost/wp/mis/?post_type=acf-field&p=37', 0, 'acf-field', '', 0),
(38, 1, '2019-08-08 06:39:01', '2019-08-08 06:39:01', '', 'Assessment', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2019-08-08 06:39:01', '2019-08-08 06:39:01', '', 18, 'http://localhost/wp/mis/18-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2019-08-09 08:25:40', '2019-08-09 08:25:40', '[wpmp_login_form]', 'Login', '', 'publish', 'closed', 'closed', '', 'login', '', '', '2019-08-09 08:29:02', '2019-08-09 08:29:02', '', 0, 'http://localhost/wp/mis/?page_id=39', 0, 'page', '', 0),
(40, 1, '2019-08-09 08:25:40', '2019-08-09 08:25:40', '', 'Login', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2019-08-09 08:25:40', '2019-08-09 08:25:40', '', 39, 'http://localhost/wp/mis/39-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2019-08-09 08:25:59', '2019-08-09 08:25:59', '[wpmp_register_form]', 'Register', '', 'publish', 'closed', 'closed', '', 'register', '', '', '2019-08-14 11:51:52', '2019-08-14 11:51:52', '', 0, 'http://localhost/wp/mis/?page_id=41', 0, 'page', '', 0),
(42, 1, '2019-08-09 08:25:59', '2019-08-09 08:25:59', '', 'Register', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2019-08-09 08:25:59', '2019-08-09 08:25:59', '', 41, 'http://localhost/wp/mis/41-revision-v1/', 0, 'revision', '', 0),
(43, 1, '2019-08-09 08:27:24', '2019-08-09 08:27:24', '[wpmp_user_profile]', 'Profile', '', 'publish', 'closed', 'closed', '', 'profile', '', '', '2019-08-09 08:27:32', '2019-08-09 08:27:32', '', 0, 'http://localhost/wp/mis/?page_id=43', 0, 'page', '', 0),
(44, 1, '2019-08-09 08:27:24', '2019-08-09 08:27:24', '', 'Profile', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2019-08-09 08:27:24', '2019-08-09 08:27:24', '', 43, 'http://localhost/wp/mis/43-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2019-08-09 08:27:32', '2019-08-09 08:27:32', '[wpmp_user_profile]', 'Profile', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2019-08-09 08:27:32', '2019-08-09 08:27:32', '', 43, 'http://localhost/wp/mis/43-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2019-08-09 08:28:13', '2019-08-09 08:28:13', '[wpmp_register_form]', 'Register', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2019-08-09 08:28:13', '2019-08-09 08:28:13', '', 41, 'http://localhost/wp/mis/41-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2019-08-09 08:28:58', '2019-08-09 08:28:58', '[wpmp_login_form]', 'Login', '', 'inherit', 'closed', 'closed', '', '39-autosave-v1', '', '', '2019-08-09 08:28:58', '2019-08-09 08:28:58', '', 39, 'http://localhost/wp/mis/39-autosave-v1/', 0, 'revision', '', 0),
(48, 1, '2019-08-09 08:29:02', '2019-08-09 08:29:02', '[wpmp_login_form]', 'Login', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2019-08-09 08:29:02', '2019-08-09 08:29:02', '', 39, 'http://localhost/wp/mis/39-revision-v1/', 0, 'revision', '', 0),
(49, 1, '2019-08-12 09:48:58', '2019-08-12 09:48:58', '', 'Assessment', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2019-08-12 09:48:58', '2019-08-12 09:48:58', '', 18, 'http://localhost/wp/mis/18-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2019-08-17 03:23:24', '2019-08-17 03:23:24', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:12:\"options_page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:14:\"theme-settings\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'System Settings', 'system-settings', 'publish', 'closed', 'closed', '', 'group_5d57730266204', '', '', '2019-08-17 03:24:01', '2019-08-17 03:24:01', '', 0, 'http://localhost/wp/mis/?post_type=acf-field-group&#038;p=55', 0, 'acf-field-group', '', 0),
(56, 1, '2019-08-17 03:23:24', '2019-08-17 03:23:24', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Logo', 'logo', 'publish', 'closed', 'closed', '', 'field_5d57731302d4c', '', '', '2019-08-17 03:23:24', '2019-08-17 03:23:24', '', 55, 'http://localhost/wp/mis/?post_type=acf-field&p=56', 0, 'acf-field', '', 0),
(57, 1, '2019-08-17 03:24:01', '2019-08-17 03:24:01', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_5d57732e4dbc2', '', '', '2019-08-17 03:24:01', '2019-08-17 03:24:01', '', 55, 'http://localhost/wp/mis/?post_type=acf-field&p=57', 1, 'acf-field', '', 0),
(58, 1, '2019-08-17 03:24:01', '2019-08-17 03:24:01', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_5d5773474dbc3', '', '', '2019-08-17 03:24:01', '2019-08-17 03:24:01', '', 55, 'http://localhost/wp/mis/?post_type=acf-field&p=58', 2, 'acf-field', '', 0),
(59, 1, '2019-08-17 03:25:18', '2019-08-17 03:25:18', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:27:\"page-template/page-home.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Features Section', 'features-section', 'publish', 'closed', 'closed', '', 'group_5d57736474ffb', '', '', '2019-08-17 03:25:18', '2019-08-17 03:25:18', '', 0, 'http://localhost/wp/mis/?post_type=acf-field-group&#038;p=59', 0, 'acf-field-group', '', 0),
(60, 1, '2019-08-17 03:25:18', '2019-08-17 03:25:18', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:7:\"Add Row\";}', 'Features', 'features', 'publish', 'closed', 'closed', '', 'field_5d57736ca4714', '', '', '2019-08-17 03:25:18', '2019-08-17 03:25:18', '', 59, 'http://localhost/wp/mis/?post_type=acf-field&p=60', 0, 'acf-field', '', 0),
(61, 1, '2019-08-17 03:25:18', '2019-08-17 03:25:18', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_5d57737aa4715', '', '', '2019-08-17 03:25:18', '2019-08-17 03:25:18', '', 60, 'http://localhost/wp/mis/?post_type=acf-field&p=61', 0, 'acf-field', '', 0),
(62, 1, '2019-08-17 03:25:18', '2019-08-17 03:25:18', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_5d577385a4716', '', '', '2019-08-17 03:25:18', '2019-08-17 03:25:18', '', 60, 'http://localhost/wp/mis/?post_type=acf-field&p=62', 1, 'acf-field', '', 0),
(63, 1, '2019-08-17 03:26:49', '2019-08-17 03:26:49', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2019-08-17 03:26:49', '2019-08-17 03:26:49', '', 0, 'http://localhost/wp/mis/wp-content/uploads/2019/08/logo.png', 0, 'attachment', 'image/png', 0),
(64, 1, '2019-08-17 03:27:20', '2019-08-17 03:27:20', '', 'img-features-survey', '', 'inherit', 'open', 'closed', '', 'img-features-survey', '', '', '2019-08-17 03:27:20', '2019-08-17 03:27:20', '', 27, 'http://localhost/wp/mis/wp-content/uploads/2019/08/img-features-survey.png', 0, 'attachment', 'image/png', 0),
(65, 1, '2019-08-17 03:27:58', '2019-08-17 03:27:58', '', '490x180', '', 'inherit', 'open', 'closed', '', '490x180', '', '', '2019-08-17 03:27:58', '2019-08-17 03:27:58', '', 27, 'http://localhost/wp/mis/wp-content/uploads/2019/08/490x180.png', 0, 'attachment', 'image/png', 0),
(66, 1, '2019-08-17 03:28:27', '2019-08-17 03:28:27', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam et interdum purus. Phasellus nec mi ac <strong>tellus</strong> faucibus cursus quis venenatis enim. Sed volutpat est sit amet sagittis vehicula. Phasellus cursus pharetra pellentesque. <a href=\"#\">Nunc</a> hendrerit urna ultricies, egestas orci et, auctor massa. Mauris facilisis leo sit amet elit iaculis pulvinar. Vestibulum id blandit tortor.\r\n<ul>\r\n 	<li>Lorem ipsum dolor sit amet</li>\r\n 	<li>Etiam et interdum</li>\r\n</ul>', 'HOME', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2019-08-17 03:28:27', '2019-08-17 03:28:27', '', 27, 'http://localhost/wp/mis/27-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2019-08-27 09:27:46', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-08-27 09:27:46', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/mis/?p=67', 0, 'post', '', 0),
(68, 1, '2019-08-27 09:28:19', '2019-08-27 09:28:19', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam et interdum purus. Phasellus nec mi ac <strong>tellus</strong> faucibus cursus quis venenatis enim. Sed volutpat est sit amet sagittis vehicula. Phasellus cursus pharetra pellentesque. <a href=\"#\">Nunc</a> hendrerit urna ultricies, egestas orci et, auctor massa. Mauris facilisis leo sit amet elit iaculis pulvinar. Vestibulum id blandit tortor.\r\n<ul>\r\n 	<li>Lorem ipsum dolor sit amet</li>\r\n 	<li>Etiam et interdum</li>\r\n</ul>', 'Home', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2019-08-27 09:28:19', '2019-08-27 09:28:19', '', 27, 'http://localhost/wp/mis/27-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2019-08-27 09:48:50', '2019-08-27 09:48:50', '', 'Assessment', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2019-08-27 09:48:50', '2019-08-27 09:48:50', '', 18, 'http://localhost/wp/mis/18-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2019-08-27 09:52:28', '2019-08-27 09:52:28', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:7:\"Add Row\";}', 'Networks', 'networks', 'publish', 'closed', 'closed', '', 'field_5d64fd527c4dd', '', '', '2019-08-27 09:52:28', '2019-08-27 09:52:28', '', 21, 'http://localhost/wp/mis/?post_type=acf-field&p=70', 1, 'acf-field', '', 0),
(71, 1, '2019-08-27 09:52:28', '2019-08-27 09:52:28', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Option', 'option', 'publish', 'closed', 'closed', '', 'field_5d64fd527c4de', '', '', '2019-08-27 09:52:28', '2019-08-27 09:52:28', '', 70, 'http://localhost/wp/mis/?post_type=acf-field&p=71', 0, 'acf-field', '', 0),
(72, 1, '2019-08-27 09:52:53', '2019-08-27 09:52:53', '', 'Assessment', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2019-08-27 09:52:53', '2019-08-27 09:52:53', '', 18, 'http://localhost/wp/mis/18-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2019-08-27 11:37:40', '2019-08-27 11:37:40', '', 'All Reports', '', 'publish', 'closed', 'closed', '', 'reports', '', '', '2019-08-27 12:09:05', '2019-08-27 12:09:05', '', 0, 'http://localhost/wp/mis/?page_id=73', 0, 'page', '', 0),
(74, 1, '2019-08-27 11:37:40', '2019-08-27 11:37:40', '', 'All Reports', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2019-08-27 11:37:40', '2019-08-27 11:37:40', '', 73, 'http://localhost/wp/mis/73-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2019-08-28 06:41:03', '2019-08-28 06:41:03', '', 'Project Details', '', 'publish', 'closed', 'closed', '', 'project-details', '', '', '2019-08-29 10:54:47', '2019-08-29 10:54:47', '', 0, 'http://localhost/wp/mis/?page_id=75', 0, 'page', '', 0),
(76, 1, '2019-08-28 06:41:03', '2019-08-28 06:41:03', '', 'Project Details', '', 'inherit', 'closed', 'closed', '', '75-revision-v1', '', '', '2019-08-28 06:41:03', '2019-08-28 06:41:03', '', 75, 'http://localhost/wp/mis/75-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2019-08-28 06:41:19', '2019-08-28 06:41:19', '', 'Project Edit', '', 'publish', 'closed', 'closed', '', 'project-edit', '', '', '2019-08-30 05:11:50', '2019-08-30 05:11:50', '', 0, 'http://localhost/wp/mis/?page_id=77', 0, 'page', '', 0),
(78, 1, '2019-08-28 06:41:19', '2019-08-28 06:41:19', '', 'Project Edit', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2019-08-28 06:41:19', '2019-08-28 06:41:19', '', 77, 'http://localhost/wp/mis/77-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2019-08-28 06:41:45', '2019-08-28 06:41:45', '', 'Project Delete', '', 'publish', 'closed', 'closed', '', 'project-delete', '', '', '2019-08-30 05:03:41', '2019-08-30 05:03:41', '', 0, 'http://localhost/wp/mis/?page_id=79', 0, 'page', '', 0),
(80, 1, '2019-08-28 06:41:45', '2019-08-28 06:41:45', '', 'Project Delete', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2019-08-28 06:41:45', '2019-08-28 06:41:45', '', 79, 'http://localhost/wp/mis/79-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2019-08-28 06:42:10', '2019-08-28 06:42:10', '<h2>Who we are</h2>\r\nOur website address is: http://localhost/wp/mis.\r\n<h2>What personal data we collect and why we collect it</h2>\r\n<h3>Comments</h3>\r\nWhen visitors leave comments on the site we collect the data shown in the comments form, and also the visitor’s IP address and browser user agent string to help spam detection.\r\n\r\nAn anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.\r\n<h3>Media</h3>\r\nIf you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.\r\n<h3>Contact forms</h3>\r\n<h3>Cookies</h3>\r\nIf you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.\r\n\r\nIf you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.\r\n\r\nWhen you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select \"Remember Me\", your login will persist for two weeks. If you log out of your account, the login cookies will be removed.\r\n\r\nIf you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.\r\n<h3>Embedded content from other websites</h3>\r\nArticles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.\r\n\r\nThese websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.\r\n<h3>Analytics</h3>\r\n<h2>Who we share your data with</h2>\r\n<h2>How long we retain your data</h2>\r\nIf you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.\r\n\r\nFor users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.\r\n<h2>What rights you have over your data</h2>\r\nIf you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.\r\n<h2>Where we send your data</h2>\r\nVisitor comments may be checked through an automated spam detection service.\r\n<h2>Your contact information</h2>\r\n<h2>Additional information</h2>\r\n<h3>How we protect your data</h3>\r\n<h3>What data breach procedures we have in place</h3>\r\n<h3>What third parties we receive data from</h3>\r\n<h3>What automated decision making and/or profiling we do with user data</h3>\r\n<h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2019-08-28 06:42:10', '2019-08-28 06:42:10', '', 3, 'http://localhost/wp/mis/3-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2019-08-31 08:49:13', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-08-31 08:49:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/mis/?page_id=82', 0, 'page', '', 0),
(83, 1, '2019-08-31 08:49:47', '2019-08-31 08:49:47', '', 'Project Actions', '', 'publish', 'closed', 'closed', '', 'project-actions', '', '', '2019-08-31 08:50:27', '2019-08-31 08:50:27', '', 0, 'http://localhost/wp/mis/?page_id=83', 0, 'page', '', 0),
(84, 1, '2019-08-31 08:49:47', '2019-08-31 08:49:47', '', 'Project Actions', '', 'inherit', 'closed', 'closed', '', '83-revision-v1', '', '', '2019-08-31 08:49:47', '2019-08-31 08:49:47', '', 83, 'http://localhost/wp/mis/83-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_project_details`
--

CREATE TABLE `wp_project_details` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `project_name` varchar(255) NOT NULL,
  `organization` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `network` varchar(100) DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `point_of_contact` varchar(255) DEFAULT NULL,
  `notes` text NOT NULL,
  `basic_requirements` text NOT NULL,
  `hardware_type` varchar(255) NOT NULL,
  `operating_system` varchar(255) NOT NULL,
  `environment_type` varchar(255) NOT NULL,
  `environment_count` int(11) NOT NULL,
  `programming_languages` varchar(255) NOT NULL,
  `storage_amount` varchar(100) NOT NULL,
  `own_data` varchar(50) NOT NULL,
  `access_rights` varchar(50) NOT NULL,
  `question_answer` longtext NOT NULL,
  `status` enum('Not Started','In-Review','Completed') NOT NULL DEFAULT 'Not Started'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_project_details`
--

INSERT INTO `wp_project_details` (`id`, `date`, `user_id`, `project_name`, `organization`, `description`, `network`, `start_date`, `end_date`, `point_of_contact`, `notes`, `basic_requirements`, `hardware_type`, `operating_system`, `environment_type`, `environment_count`, `programming_languages`, `storage_amount`, `own_data`, `access_rights`, `question_answer`, `status`) VALUES
(48, '2019-09-02 12:57:29', 3, 'Test Project3333', 'Option 2', 'Test Project1111', 'TS', '2019-09-09 00:00:00', '2019-10-14 00:00:00', 'Test Project1111', 'Test Project1111', 'Test Project1111', 'Keyboard', 'Mac', 'Live', 4, 'PHP', '10 GB', 'No', 'Yes', '[{\"id\":6,\"question\":\"Question 1\",\"answer\":\"Test Project1111Test Project1111Test Project1111Test Project1111\"},{\"id\":7,\"question\":\"Question 2\",\"answer\":\"Test Project1111Test Project1111Test Project1111\"},{\"id\":8,\"question\":\"Question 3\",\"answer\":\"Test Project1111Test Project1111Test Project1111Test Project1111Test Project1111\"},{\"id\":9,\"question\":\"Question 4\",\"answer\":\"Test Project1111Test Project1111Test Project1111Test Project1111Test Project1111Test Project1111Test Project1111\"},{\"id\":10,\"question\":\"Question 5\",\"answer\":\"Test Project1111Test Project1111Test Project1111Test Project1111Test Project1111Test Project1111\"},{\"id\":11,\"question\":\"Question 6\",\"answer\":\"Test Project1111\"},{\"id\":12,\"question\":\"Question 7\",\"answer\":\"Test Project1111Test Project1111Test Project1111Test Project1111\"},{\"id\":13,\"question\":\"Question 8\",\"answer\":\"Test Project1111\"},{\"id\":14,\"question\":\"Question 9\",\"answer\":\"Test Project1111\"},{\"id\":15,\"question\":\"Question 10\",\"answer\":\"Test Project1111\"},{\"id\":16,\"question\":\"Question 11\",\"answer\":\"Test Project1111\"}]', 'Not Started');

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', 'Administrator'),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy,plugin_editor_notice'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '67'),
(18, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(19, 1, 'metaboxhidden_dashboard', 'a:0:{}'),
(20, 1, 'acf_user_settings', 'a:0:{}'),
(21, 1, 'closedpostboxes_page', 'a:0:{}'),
(22, 1, 'metaboxhidden_page', 'a:8:{i:0;s:23:\"acf-group_5d57736474ffb\";i:1;s:23:\"acf-group_5d57730266204\";i:2;s:12:\"revisionsdiv\";i:3;s:10:\"postcustom\";i:4;s:16:\"commentstatusdiv\";i:5;s:11:\"commentsdiv\";i:6;s:7:\"slugdiv\";i:7;s:9:\"authordiv\";}'),
(23, 1, 'wp_user-settings', 'editor=tinymce&libraryContent=browse'),
(24, 1, 'wp_user-settings-time', '1566012418'),
(25, 2, 'nickname', 'nextgenanakgida'),
(26, 2, 'first_name', 'Nextgen'),
(27, 2, 'last_name', 'Anak'),
(28, 2, 'description', ''),
(29, 2, 'rich_editing', 'true'),
(30, 2, 'syntax_highlighting', 'true'),
(31, 2, 'comment_shortcuts', 'false'),
(32, 2, 'admin_color', 'fresh'),
(33, 2, 'use_ssl', '0'),
(34, 2, 'show_admin_bar_front', 'true'),
(35, 2, 'locale', ''),
(36, 2, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(37, 2, 'wp_user_level', '0'),
(38, 2, 'dismissed_wp_pointers', 'wp496_privacy'),
(39, 2, 'dismissed_wp_pointers', 'wp496_privacy'),
(41, 3, 'nickname', 'anakgida'),
(42, 3, 'first_name', 'Nextgen'),
(43, 3, 'last_name', 'Anak'),
(44, 3, 'description', ''),
(45, 3, 'rich_editing', 'true'),
(46, 3, 'syntax_highlighting', 'true'),
(47, 3, 'comment_shortcuts', 'false'),
(48, 3, 'admin_color', 'fresh'),
(49, 3, 'use_ssl', '0'),
(50, 3, 'show_admin_bar_front', 'true'),
(51, 3, 'locale', ''),
(52, 3, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(53, 3, 'wp_user_level', '0'),
(54, 3, 'dismissed_wp_pointers', 'wp496_privacy'),
(55, 3, 'dismissed_wp_pointers', 'wp496_privacy'),
(57, 3, 'session_tokens', 'a:2:{s:64:\"117cec847e31aee832f082aa7dfcb2411bb46e54e79884037b8d0e9b4e36d950\";a:4:{s:10:\"expiration\";i:1567576279;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0\";s:5:\"login\";i:1567403479;}s:64:\"1c4a93a191e223a18ddab524bda8cf6415538e34d11e06a0cac4d775eed61e94\";a:4:{s:10:\"expiration\";i:1567576295;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0\";s:5:\"login\";i:1567403495;}}'),
(58, 3, 'wpmp_profile_pic', 'http://localhost/wp/mis/wp-content/uploads/2019/08/0266554465.jpeg'),
(60, 4, 'nickname', 'nextgenanakgida1233'),
(61, 4, 'first_name', 'Nextgen'),
(62, 4, 'last_name', 'Anak'),
(63, 4, 'description', ''),
(64, 4, 'rich_editing', 'true'),
(65, 4, 'syntax_highlighting', 'true'),
(66, 4, 'comment_shortcuts', 'false'),
(67, 4, 'admin_color', 'fresh'),
(68, 4, 'use_ssl', '0'),
(69, 4, 'show_admin_bar_front', 'true'),
(70, 4, 'locale', ''),
(71, 4, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(72, 4, 'wp_user_level', '0'),
(73, 4, 'dismissed_wp_pointers', 'wp496_privacy'),
(74, 4, 'dismissed_wp_pointers', 'wp496_privacy'),
(75, 4, 'wpmp_email_verification_token', '377ad656492edede48bbddd255475434'),
(76, 5, 'nickname', 'nextgenanakgida12333'),
(77, 5, 'first_name', 'Nextgen'),
(78, 5, 'last_name', 'Anak'),
(79, 5, 'description', ''),
(80, 5, 'rich_editing', 'true'),
(81, 5, 'syntax_highlighting', 'true'),
(82, 5, 'comment_shortcuts', 'false'),
(83, 5, 'admin_color', 'fresh'),
(84, 5, 'use_ssl', '0'),
(85, 5, 'show_admin_bar_front', 'true'),
(86, 5, 'locale', ''),
(87, 5, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(88, 5, 'wp_user_level', '0'),
(89, 5, 'dismissed_wp_pointers', 'wp496_privacy'),
(90, 5, 'dismissed_wp_pointers', 'wp496_privacy'),
(91, 5, 'wpmp_email_verification_token', 'd0819669033a66ff492483a186ad3ff8'),
(92, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(93, 1, 'managetoplevel_page_wp_list_table_classcolumnshidden', 'a:0:{}'),
(94, 1, 'projects_per_page', '10'),
(95, 1, 'session_tokens', 'a:2:{s:64:\"97625b8bd96411845a6d3375f032ecc3eb0df96adf3e0bc188cf5d3188cab395\";a:4:{s:10:\"expiration\";i:1567601643;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0\";s:5:\"login\";i:1567428843;}s:64:\"56f2618c7285165364bd8082baea9d0f6b21c668ad3a1c2d8965c6d43bcfe8ad\";a:4:{s:10:\"expiration\";i:1567601643;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0\";s:5:\"login\";i:1567428843;}}'),
(96, 6, 'nickname', 'nextgennextgennextgen'),
(97, 6, 'first_name', 'Nextgen'),
(98, 6, 'last_name', 'Nextgen'),
(99, 6, 'description', ''),
(100, 6, 'rich_editing', 'true'),
(101, 6, 'syntax_highlighting', 'true'),
(102, 6, 'comment_shortcuts', 'false'),
(103, 6, 'admin_color', 'fresh'),
(104, 6, 'use_ssl', '0'),
(105, 6, 'show_admin_bar_front', 'true'),
(106, 6, 'locale', ''),
(107, 6, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(108, 6, 'wp_user_level', '0'),
(109, 6, 'dismissed_wp_pointers', 'wp496_privacy'),
(110, 6, 'dismissed_wp_pointers', 'wp496_privacy'),
(112, 6, 'session_tokens', 'a:1:{s:64:\"c516b6dfedd56c35cb460fde96abd1787d4b7f331ca3ecf33264cbeb476d0c00\";a:4:{s:10:\"expiration\";i:1567150737;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0\";s:5:\"login\";i:1566977937;}}'),
(113, 7, 'nickname', 'nextgennextgennextgen7777'),
(114, 7, 'first_name', 'Nextgen'),
(115, 7, 'last_name', 'Nextgen'),
(116, 7, 'description', ''),
(117, 7, 'rich_editing', 'true'),
(118, 7, 'syntax_highlighting', 'true'),
(119, 7, 'comment_shortcuts', 'false'),
(120, 7, 'admin_color', 'fresh'),
(121, 7, 'use_ssl', '0'),
(122, 7, 'show_admin_bar_front', 'true'),
(123, 7, 'locale', ''),
(124, 7, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(125, 7, 'wp_user_level', '0'),
(126, 7, 'dismissed_wp_pointers', 'wp496_privacy'),
(127, 7, 'dismissed_wp_pointers', 'wp496_privacy'),
(129, 7, 'session_tokens', 'a:2:{s:64:\"44982118965bced0e292ff4195ca5aa158c4cab7375985a90417c496f596bce1\";a:4:{s:10:\"expiration\";i:1567158297;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0\";s:5:\"login\";i:1566985497;}s:64:\"8dfd237644b1a97295666ef53a4b5a3b2b54b64821f2c3be01df76af65138b14\";a:4:{s:10:\"expiration\";i:1567314257;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0\";s:5:\"login\";i:1567141457;}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BqpNO8EaUp6rm0qGUXrE/qbIhAVa.J/', 'admin', 'nextgenanakgida@gmail.com', '', '2019-08-05 12:35:22', '', 0, 'admin'),
(2, 'nextgenanakgida', '$P$BSJ5/8ZjWW.3cc9lcaxc0s3/AnZpnc0', 'nextgenanakgida', 'anakgida@gmail.com', '', '2019-08-09 08:57:04', '', 0, 'Nextgen Anak'),
(3, 'anakgida', '$P$B1J2v6QmfwHbM1buiITDbYd0X6Hu4T/', 'anakgida', 'anakgida2@gmail.com', '', '2019-08-12 05:23:16', '', 0, 'Nextgen Anak'),
(4, 'nextgenanakgida1233', '$P$BKugyOwKMKCEC6yWCmK9dgHB.4PH4B.', 'nextgenanakgida1233', 'nextgenanakgida1233@gmail.com', '', '2019-08-12 09:45:36', '', 0, 'Nextgen Anak'),
(5, 'nextgenanakgida12333', '$P$BfgkMjtRyyC8mYJAlXEF4EqcH/f6iy.', 'nextgenanakgida12333', 'nextgenanakgida12333@gmail.com', '', '2019-08-12 10:02:32', '', 0, 'Nextgen Anak'),
(6, 'nextgennextgennextgen', '$P$B/JN6iWMn/5TP4XLm.94.vxAUbAWCx.', 'nextgennextgennextgen', 'nextgennextgennextgen@gmail.com', '', '2019-08-28 07:38:23', '', 0, 'Nextgen Nextgen'),
(7, 'nextgennextgennextgen7777', '$P$B7w0UwmCnI.TWpaVW79mB0VDAD5nI21', 'nextgennextgennextgen7777', 'nextgennextgennextgen7777@gmail.com', '', '2019-08-28 09:43:51', '', 0, 'Nextgen Nextgen');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_project_details`
--
ALTER TABLE `wp_project_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=550;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=385;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `wp_project_details`
--
ALTER TABLE `wp_project_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
