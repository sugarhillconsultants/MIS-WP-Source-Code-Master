function moveTab(options){
	var settings = $.extend({
        container           : '#dcotTabs',
        nextOrPrev    		: 'next',
        btnViewReport       : '#btnViewReport',
        btnPrev     		: '#btnPrevSection',
        btnNext   			: '#btnNextSection',
        btnSubmitAssesment 	: '#btnSubmitAssesment'

    }, options);

    var currentTab 		= "";
    var navItemElement = $(settings.container).find('li');


    navItemElement.each(function () {
        if ($(this).find('a').hasClass('active')) {
            currentTab = $(this);
        }
    });

    if (settings.nextOrPrev == "next") {

        if (currentTab.next().length) {
    		$(settings.btnPrev).removeClass('disabled');
        	var nextTab = currentTab.next().find('a').trigger('click');
        	if (!nextTab.parent().next().length) {
		    	$(settings.btnNext).hide();
		    	if(settings.container == '#dcotTabs') {
			    	$(settings.btnViewReport).removeClass('disabled');
			    	$(settings.btnSubmitAssesment).show();
		    	}
        	}
	    } else {} 

    } else {

        if (currentTab.prev().length) {
            var prevTab = currentTab.prev().find('a').trigger('click');
	    	$(settings.btnNext).show();
	    	if (!prevTab.parent().prev().length) {
	    		$(settings.btnPrev).addClass('disabled');
	    	} else {
	    		$(settings.btnViewReport).addClass('disabled');
	    		$(settings.btnSubmitAssesment).hide();
	    	}
        } else {} 
    }
}

jQuery(document).ready(function(){
	$('.js-datepicker').datepicker();

	var btnViewReport 		= '#btnViewReport';
    var btnNextSection 		= '#btnNextSection';
    var btnPrevSection 		= '#btnPrevSection';
    var btnNextQuestion 	= '#btnNextQuestion';
    var btnPrevQuestion 	= '#btnPrevQuestion';
    var btnSubmitAssesment 	= '#btnSubmitAssesment';

	$(btnSubmitAssesment).hide();


	$(btnNextQuestion).on('click', function () {
	    moveTab({
	    	container: '#questionaireTabs',
	    	nextOrPrev:'next',
	    	btnPrev     		: btnPrevQuestion,
	        btnNext   			: btnNextQuestion
	    });
	});
	$(btnPrevQuestion).on('click', function () {
	    moveTab({
	    	container: '#questionaireTabs',
	    	nextOrPrev:'prev',
	    	btnPrev     		: btnPrevQuestion,
	        btnNext   			: btnNextQuestion
	    });
	});



	$(btnNextSection).on('click', function () {
	    moveTab({nextOrPrev:'next'});
	});
	$(btnPrevSection).on('click', function () {
	    moveTab({nextOrPrev:'prev'});
	});

	$('#dcotTabs > li > a[data-toggle="tab"]').on('shown.bs.tab', function (e) {

	    var navItem = $(e.target).parent();

	    if (navItem.prev().length) {
	    	
	    	$(btnPrevSection).removeClass('disabled');

	  	    if (navItem.next().length) {
	  	    	$(btnNextSection).show();
		    	$(btnViewReport).addClass('disabled');
		    	$(btnSubmitAssesment).hide();
		    } else {
		    	$(btnNextSection).hide();
		    	$(btnViewReport).removeClass('disabled');
		    	$(btnSubmitAssesment).show();
		    }
		} else {
	  	    $(btnPrevSection).addClass('disabled');
		}
	})

});
